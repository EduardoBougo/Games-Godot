extends CharacterBody2D


const SPEED = 100.0
var direction = 1
var eliminado: bool = false


@onready var ray_direita: RayCast2D = $Direita
@onready var ray_esquerda: RayCast2D = $Esquerda
@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

@onready var ray_cima: RayCast2D = $Cima


func _physics_process(delta: float) -> void:
	
	if eliminado == false:
		# Adicionando gravidade
		if not is_on_floor():
			velocity += get_gravity() * delta
		
		if ray_direita.is_colliding():
			direction *= -1
			scale.x *= -1
		
		if ray_esquerda.is_colliding():
			direction *= -1
			scale.x *= -1
		
		velocity.x = SPEED * direction
		animated_sprite_2d.play("idle")
		
		if ray_cima.is_colliding():
			eliminado == true
		
		move_and_slide()
	
	else:
		animated_sprite_2d.stop()
		animated_sprite_2d.play("dead")
		
		await get_tree().create_timer(1.0).timeout
		
		queue_free()
		
